# stem_mtec_smart_farm
